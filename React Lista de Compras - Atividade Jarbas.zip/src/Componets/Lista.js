import React, { Component } from "react";

export class Lista extends Component {
  render() {
    return (
      <div>
        <label>
          Digite o texto:
          <input onKeyUp={this.props.onAddTask} autoFocus type="text" />
        </label>
        <p>Texto Digitado:</p>
        <ul>
          {this.props.tasks.map(task => {
             return <li>{task}</li>       
            })}
        </ul>
      </div>
    );
  }
}
